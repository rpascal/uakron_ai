#3460:460  Project #1

### Running Project
This project is built using Maven, the target jar is already built 
and packaged but if you would like to rebuild the jar run the following:
`mvn package`

Once the jar is built the program can either to run by executing `./run.sh`
or by running `java -cp target/p_2732-1.0-jar-with-dependencies.jar com.uakron.ai.Main`



