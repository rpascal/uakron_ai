#!/bin/bash

java -cp target/p_2732-1.0-jar-with-dependencies.jar com.uakron.ai.Main